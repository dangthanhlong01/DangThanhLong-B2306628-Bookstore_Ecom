import { createRouter, createWebHistory } from 'vue-router'
import AdminLayout from '../layouts/AdminLayout.vue'

const routes = [
  {
    path: '/admin',
    component: AdminLayout,
    children: [
      {
        path: 'users',
        name: 'admin-user-list',
        component: () => import('../views/UserManagement.vue'),
        meta: { title: 'Quản lý người dùng' },
      },
    ],
  },
  {
    path: '/',
    redirect: '/admin/users',
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

router.afterEach((to) => {
  document.title = to.meta.title || 'Trang quản trị'
})

export default router