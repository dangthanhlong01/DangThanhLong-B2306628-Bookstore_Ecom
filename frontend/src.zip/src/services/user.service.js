import axiosClient from './axiosClient'

const userService = {
  /**
   * Lấy danh sách người dùng có phân trang + tìm kiếm theo SĐT
   * @param {{page:number, limit:number, phone?:string}} params
   */
  getUsers(params = {}) {
    return axiosClient.get('/users', { params })
  },

  getUserById(id) {
    return axiosClient.get(`/users/${id}`)
  },

  createUser(data) {
    return axiosClient.post('/users', data)
  },

  updateUser(id, data) {
    return axiosClient.put(`/users/${id}`, data)
  },

  deleteUser(id) {
    return axiosClient.delete(`/users/${id}`)
  },

  exportExcel(params = {}) {
    return axiosClient.get('/users/export-excel', {
      params,
      responseType: 'blob',
    })
  },
}

export default userService
